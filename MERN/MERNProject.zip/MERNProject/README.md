## Contribution in let's Help Ngo webapp.

# Yash Patel
1. Initial Project setup - database connection and design
2. index.js(route setup)
3. Authentication using jwt and middleware
4. Models - Ngos, User, Product
5. Server Side validation of User
6. Routes - auth(login),Ngo(CRUD),user(signup)

# Rishi Suri
1. Database Design,
2. route setup,
3. Server side validation of Product,
4. Routes - User,


#Aditya Tuli 
1. Models - Ngos,
2. Server side validation of Ngos,
3. Routes Redesign - user,Ngos


# Heroku Deployment
https://gladiators-digital-diary.herokuapp.com/

# Our Initial Work on different Repo

