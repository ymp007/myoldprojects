import React, { Component } from 'react'
import './UserDashBoard.css'
import NavigationBar from './NavigationBar/NavigationBar'
import { Container } from 'react-bootstrap'
// import { BrowserRouter, Switch, Route } from 'react-router-dom'
// import Profile from './Profile/Profile'
import NGOs from './NGOs/NGOs'
import Footer from './Footer/Footer'
import { Route, BrowserRouter, Switch } from 'react-router-dom'
// import Login from './Login/Login'
// import DonationForm from './DonationForm/DonationForm'
import DonationList from './DonationList/DonationsList';
import NgoProfiles from './NgoProfiles/NgoProfiles'
export default class NgoDashBoard extends Component {
    render() {
        return (
            <div className="main-con">
                <NavigationBar />
                <Container>
                    <BrowserRouter>
                        <Switch>
                            <Route exact path="/ngo/donations" component={DonationList} />
                            <Route exact path="/ngo/profile" component={NgoProfiles} />
                            <Route exact path="/ngo/conformation" component={NgoDashBoard} />
                        </Switch>
                    </BrowserRouter>
                </Container>
                <Footer />
            </div>
        )
    }
}
