import React, { Component } from 'react'
import { Container, Col, Row, Button } from 'react-bootstrap'
import './ThankYou.css'

export default class ThankYou extends Component {
    render() {
        return (
            <div>
                <div className="main-con">
                <Container className="thankyou gray-container">
                    <Row  className="thankyou-text">
                        <Col>
                            <h1>Thank You!</h1>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <h6>We appriciate your help to the community and kindness towards people</h6>
                        </Col>
                    </Row>
                    <Row className="thankyou-donations">
                        <Col>
                            <Button variant="outline-success">My Donations</Button>
                        </Col>
                    </Row>
                </Container>
                </div>
            </div>
        )
    }
}
