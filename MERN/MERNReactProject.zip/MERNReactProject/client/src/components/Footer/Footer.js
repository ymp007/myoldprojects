import React, { Component } from 'react'
import { Navbar } from 'react-bootstrap'
import { Nav } from 'react-bootstrap'

export default class Footer extends Component {
    render() {
        return (
            <div>
                <Navbar bg="dark" variant="dark">
    <Nav.Link>© YMP Co. Op. </Nav.Link>
    <Nav className="ml-auto">
      <Nav.Link href="/">Home</Nav.Link>
      <Nav.Link href="/ngos">Ngos</Nav.Link>
      <Nav.Link href="#pricing">Carrers</Nav.Link>
    </Nav>
  </Navbar>
            </div>
        )
    }
}
