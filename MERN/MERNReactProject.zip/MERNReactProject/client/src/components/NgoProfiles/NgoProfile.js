import React, { Component } from 'react'
import { Container, Row, Col } from 'react-bootstrap'

export default class NgoProfile extends Component {
    render() {
        return (
            <div>
                <Container className="main-container">
                    <Row>
                        <Col>
                            <h1>HELLO WORLD</h1>
                        </Col>
                    </Row>
                </Container>
            </div>
        )
    }
}
