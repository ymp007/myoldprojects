import React, { Component } from 'react'
import { Container, Table, Row, Col, Button } from 'react-bootstrap'
import './MyDonation.css'

export default class MyDonations extends Component {
    render() {
        return (
            <div>
                <Container className="thankyou">
                    <Row>
                        <Col>
                        <h1>My Donations</h1>
                        </Col>
                    </Row>
                    <Row>
                <Table responsive>
  <thead>
    <tr>
      <th>Product Name</th>
      <th>Product Details</th>
      <th>Category</th>
      <th>Ngo</th>
      <th>Date of Donation</th>
      <th>Quantity</th>
      <th>Change Donation</th>
      <th>Delete Donation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td><Button variant="outline-primary">Change</Button></td>
      <td><Button variant="outline-danger">Delete</Button></td>
    </tr>
    <tr>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td><Button variant="outline-primary">Change</Button></td>
      <td><Button variant="outline-danger">Delete</Button></td>
    </tr>
    <tr>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td><Button variant="outline-primary">Change</Button></td>
      <td><Button variant="outline-danger">Delete</Button></td>
    </tr>
    <tr>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td><Button variant="outline-primary">Change</Button></td>
      <td><Button variant="outline-danger">Delete</Button></td>
    </tr>
    <tr>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td><Button variant="outline-primary">Change</Button></td>
      <td><Button variant="outline-danger">Delete</Button></td>
    </tr>
    <tr>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td>Table cell</td>
      <td><Button variant="outline-primary">Change</Button></td>
      <td><Button variant="outline-danger">Delete</Button></td>
    </tr>
  </tbody>
</Table>
</Row>
                </Container>
            </div>
        )
    }
}
