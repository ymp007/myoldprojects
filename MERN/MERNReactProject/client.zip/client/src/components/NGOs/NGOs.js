import React, { Component } from 'react'
import { Card, Container, Col } from 'react-bootstrap'
import './NGOs.css'
import { Row } from 'react-bootstrap';
import axios from 'axios';

export default class NGOs extends Component {
    state = {
        ngos:[]
    }
    handleCardClick(ngoid,ngoname) {
        // this.props.history.push('/donation/'+ngoid);
       
    }
    componentDidMount() {
        axios.get('https://ngonodeapi.herokuapp.com//api/ngos/')
        .then(res => {
            this.setState({ngos:res.data})
        }
        )
    }
    render() {
        return (
            <div>
                <Container className="main-container thankyou">
                    <Row>
                        <Col>
                        <h1>Ngos Work With Us</h1>
                        </Col>
                    </Row>
                    <Row>
                    {
                        this.state.ngos.map(ngo => {
                            return <div key={ngo._id}>
                            <Card className="ngo-card"  style={{ width: '18rem' }} onClick={this.handleCardClick.bind(this,ngo._id,ngo.name)}>
                                <Card.Header><Card.Title>{ngo.name}</Card.Title></Card.Header>
                                <Card.Text>
                                    {ngo.detail}
                                </Card.Text>
                                <Card.Footer>{ngo.address}</Card.Footer>
                        </Card>
                        </div>
                        })
                    }
                    </Row>
                </Container>
            </div>
        )
    }
}
