import React, { Component } from "react";
import { Container, Row, Col } from "react-bootstrap";
import ReactPlayer from "react-player";
import Button from 'react-bootstrap/Button';
import axios from "axios";

// css
import  './NgoProfiles.css';



export default class NgoProfile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ngoid: "5e93a0633227dd4f1c2f651d",
      ngoname: null,
      phone: null,
      address: null,
      detail: null,
      link: null,
    };
  }

  handleApply = (event) => {
    const data = {
      ngo_id: this.state.ngoid,
      ngo_name: this.state.ngoname,
    };
    this.props.history.push({
      pathname: "/donation",
      state: { detail: data },
    });
  };

  componentDidMount() {
    axios
      .get("https://ngonodeapi.herokuapp.com/api/ngos/5e93a0633227dd4f1c2f651d")
      .then((res) => {
        console.log(res.data._id);
        this.setState({
          ngoid: res.data._id,
          ngoname: res.data.name,
          phone: res.data.phone,
          address: res.data.address,
          detail: res.data.detail,
          link: res.data.link,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  }
  render() {
    return (
      <div>
        <Container className="main-container thankyou">
          <Row>
            <Col sm ={3}></Col>
            <Col sm ={3}></Col>
            <Col sm ={3}></Col>
            <Col sm ={3}><Button onClick={this.handleApply} variant="success">Donate</Button></Col>
          </Row>
          <Row>
            <Col>
              NGO Name <h1>{this.state.ngoname}</h1>
            </Col>
          </Row>

          <Row>
            <Col className='detail'>
              detail <h1>{this.state.detail}</h1>
            </Col>
          </Row>
          <Row>
            <Col className="d-flex justify-content-center">
              <ReactPlayer
                url="https://www.youtube.com/watch?v=tbnzAVRZ9Xc"
                playing
                controls
              />
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}