import React, { Component } from 'react'
import { Container, Table, Row, Col, Button } from 'react-bootstrap'
import './MyDonation.css'
import { withRouter } from 'react-router-dom';
import axios from 'axios';
import decode from 'jwt-decode'
class MyDonations extends Component {
  constructor(props) {
    super(props);
    this.state = {
      donatinos: [],
      user:[]
    }
  }

  componentDidMount() {
    var decode_id = decode(localStorage.getItem("userToken"))
    
    axios.get('https://ngonodeapi.herokuapp.com/api/products/')
      .then(res => {
          let donate = res.data.filter(ele=>{
            if(ele.userid===decode_id.user.id){
              return true;
            }
          })   
          this.setState({donatinos:donate})
      }
      ).catch(err => {
        alert(err);
      })
      
  }

  handleDelete = event => {
    axios.delete('https://ngonodeapi.herokuapp.com//api/products/' + event.target.value)
      .then(res => {
        alert("your product was deleted")
        this.setState({donatinos:res.data})
      }
      ).catch(err => {
        alert(err);
      })
  }
  handleEdit =event => {
    const data = {
      productid: event.target.value
    };
    this.props.history.push({
      pathname: "/editdonation",
      state: { detail: data },
    });
  }

  render() {
    return (
      <div>
        <Container className="thankyou">
          <Row>
            <Col>
              <h1>My Donations</h1>
            </Col>
          </Row>
          <Row>
            <Col>
              <Button variant="success" className="donate-more" onClick={() => { this.props.history.push('/ngos') }} >Donate More</Button>
            </Col>
          </Row>
          <Row>
            <Table responsive>
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>Product Details</th>
                  <th>Category</th>
                  <th>Ngo</th>
                  <th>Date of Donation</th>
                  <th>Quantity</th>
                  <th>Change Donation</th>
                  <th>Delete Donation</th>
                </tr>
              </thead>
              <tbody>
                {
                  
                  this.state.donatinos.map((product) => {
                    return (
                      (
                        <tr>
                           <td>{product.productName}</td>
                           <td>{product.details}</td>
                           <td>{product.category}</td>
                           <td>{product.NgoId}</td>
                           <td>{product.dateofDonation}</td>
                           <td>{product.quantity}</td>
                           <td><Button variant="outline-primary" onClick={this.handleEdit} value={product._id}>Change</Button></td>
                           <td><Button variant="outline-danger" onClick={this.handleDelete} value={product._id}>Delete</Button></td>
                         </tr>)
                    );
                  } 
                  )
                }
              </tbody>
            </Table>
          </Row>
        </Container>
      </div>
    )
  }
}
export default withRouter(MyDonations);