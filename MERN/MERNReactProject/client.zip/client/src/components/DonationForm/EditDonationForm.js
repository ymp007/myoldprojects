import React, { Component } from 'react'
import './DonationForm.css';
import { Container, Row, Col, Alert } from 'react-bootstrap';
import axios from 'axios'
import decode from 'jwt-decode'
import {withRouter} from 'react-router-dom'
class EditDonationForm extends Component {
    constructor(props){
        super(props)
        this.state={
            ngoid:"",
            productid:"",
            ngoname:"",
            category:[],
            show:false,
            variant:"success",
            alert:"",
            alertTitle:"",
            selectedcategory:"",
            selectedproduct:[]
        }
    }
    
    componentDidMount(){
        this.setState({ngoid:this.props.location.state.detail.ngo_id});
        this.setState({ngoname:this.props.location.state.detail.ngo_name});
        axios.get('https://ngonodeapi.herokuapp.com//api/category/')
        .then(res => {
            this.setState({category:res.data})
            console.log(res.data);
            axios.get('https://ngonodeapi.herokuapp.com//api/products/'+this.props.location.state.detail.productid)
            .then(res => {
                this.setState({selectedproduct:res.data})
                this.setState({productid:this.props.location.state.detail.productid})
                console.log(res.data);
            }
            )
        }
        )
       
    }
    handleSubmit = event =>{
        event.preventDefault();
        const config= {
            headers: {
                'Content-Type': 'application/json'
            }
        }
        if(event.target.productName.value!==""&&event.target.details.value!==""&&event.target.donationDate.value!==""&&this.state.selectedcategory!==""){
            var decode_id = decode(localStorage.getItem("userToken"));
            const data={
            userid:decode_id.user.id,
            productname:event.target.productName.value,
            details:event.target.details.value,
            category:this.state.selectedcategory,
            NgoId:this.state.ngoid,
            dateofDonation:event.target.donationDate.value,
            quantity:event.target.quantity.value,
            donated:false
        }
        
        console.log(data)
        axios.put('https://ngonodeapi.herokuapp.com//api/products/'+this.state.productid,data,{config})
        .then(res => {
            this.setState({alertTitle:"Your Donation is Changed. If you want to see your donation you can see that using mydonation tab or you can donate more."})
        this.setState({variant:"success"})    
        this.setState({show:true})
            
        }
        ).catch(err =>{
            alert(err);
        })
    }else{
        this.setState({alertTitle:"Please Enter Details Properly"})
        this.setState({variant:"danger"})    
        this.setState({show:true})         
    }
    }
    categoryChanged = event => {
        this.setState({selectedcategory:event.target.value})
    }
    render() {
        return (
            <div>
                 
                <Container className="donation-container">
                <Alert variant={this.state.variant} show={this.state.show} onClose={() => this.setState({show:false})} dismissible>
        <Alert.Heading>{this.state.alertTitle}</Alert.Heading>
        <p>
             {this.state.alert}
        </p>
      </Alert>
                <Row className="d-flex donation-heading">
                        <Col md={12}>
                            <h1>Donation Form</h1>
                        </Col>
                    </Row>
                    <form onSubmit={this.handleSubmit}>
                    <Row className="d-flex justify-content-center">
                        <Col md={5}>
                            <label>Product Name: </label>
                            <input type="text" className="form-control" name="productName" placeholder="Enter Product name" defaultValue={this.state.selectedproduct.productName}/>
                        </Col>
                    </Row>
                    <Row className="d-flex justify-content-center">
                        <Col md={5}>
                            <label>Product Details: </label>
                            <textarea name="details" className="form-control donation-details" rows="10" defaultValue={this.state.selectedproduct.details}>
                            </textarea>
                        </Col>
                    </Row>
                    <Row className="d-flex justify-content-center">
                        <Col md={5}>
                            <label>Category: </label>
                            <select name="Ngos" className="form-control" onChange={this.categoryChanged}>
                                <option value="">--Please Select Category--</option>
                                {this.state.category.map(cat=>{
                                    return <option key={cat._id} value={cat._id}>{cat.name}</option>
                                })}
                            </select>
                        </Col>
                    </Row>
                    <Row className="d-flex justify-content-center">
                        <Col md={5}>
                            <label>Date of Donation: </label>
                            <input type="date" className="form-control" name="donationDate" defaultValue={this.state.selectedproduct.dateofDonation}/>
                        </Col>
                    </Row>
                    <Row className="d-flex justify-content-center">
                        <Col md={5}>
                            <label>Quantity: </label>
                            <input type="number" min="1" className="form-control" name="quantity" placeholder="Enter Product Quantity" defaultValue={this.state.selectedproduct.quantity}/>
                        </Col>
                    </Row>
                    <Row>
                        <Col md={5}>
                            <input type="submit" className="btn btn-primary btn-donate" value="Change"/>
                        </Col>
                    </Row>
                    </form>
                </Container>
            </div>
        )
    }
}
export default withRouter(EditDonationForm);