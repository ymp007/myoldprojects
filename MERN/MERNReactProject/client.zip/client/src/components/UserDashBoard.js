import React, { Component } from 'react'
import './UserDashBoard.css'
import NavigationBar from './NavigationBar/NavigationBar'
import { Container } from 'react-bootstrap'
// import { BrowserRouter, Switch, Route } from 'react-router-dom'
// import Profile from './Profile/Profile'
import NGOs from './NGOs/NGOs'
import Footer from './Footer/Footer'
import { BrowserRouter, Switch, Route } from 'react-router-dom'
// import Login from './Login/Login'
import DonationForm from './DonationForm/DonationForm'
import NgoProfile from './NgoProfiles/NgoProfile'
import ThankYou from './ThankYou/ThankYou'
import MyDonations from './MyDonations/MyDonations'
import EditDonationForm from './DonationForm/EditDonationForm'

export default class UserDashBoard extends Component {
    render() {
        return (
            <div className="main-con">
                {/* <Login/> */}
                <NavigationBar />
                <Container className="user-main">
                    <BrowserRouter>
                        <Switch>
                            <Route exact path="/ngos" component={NGOs} />
                            <Route exact path="/ngos/:id" component={NgoProfile} />
                            <Route exact path="/donation" component={DonationForm} />
                            <Route exact path="/editdonation" component={EditDonationForm} />
                            <Route exact path="/mydonation" component={MyDonations} />
                            <Route exact path="/thankyou" component={ThankYou} />
                        </Switch>
                    </BrowserRouter>

                </Container>
                <Footer />
            </div>
        )
    }
}
