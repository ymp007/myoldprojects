import React, { Component } from 'react'
import { Container, Row, Col, Card } from 'react-bootstrap'
import './DonationList.css'

export default class DonationList extends Component {
  render() {
    return (
      <div>
        <Container className="thankyou donation-list">
          <Row>
            <Col>
              <h1>Donations</h1>
            </Col>
          </Row>
          <Row>
            <Card style={{ width: '18rem' }}>
              <Card.Body>
                <Card.Title>Yash Patel</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">Clothes</Card.Subtitle>
                <Card.Text>
                  I want to donate my old clothes and shoes
                </Card.Text>
                <Card.Link href="#" className="btn btn-collect btn-outline-success" >Collected Donation</Card.Link>
                <Card.Footer>
                  7,Joshua Avenue
                </Card.Footer>
              </Card.Body>
            </Card>
            <Card style={{ width: '18rem' }}>
              <Card.Body>
                <Card.Title>Yash Patel</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">Clothes</Card.Subtitle>
                <Card.Text>
                  I want to donate my old clothes and shoes
                </Card.Text>
                <Card.Link href="#" className="btn btn-collect btn-outline-success" >Collected Donation</Card.Link>
                <Card.Footer>
                  7,Joshua Avenue
                </Card.Footer>
              </Card.Body>
            </Card>
            <Card style={{ width: '18rem' }}>
              <Card.Body>
                <Card.Title>Yash Patel</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">Clothes</Card.Subtitle>
                <Card.Text>
                  I want to donate my old clothes and shoes
                </Card.Text>
                <Card.Link href="#" className="btn btn-collect btn-outline-success" >Collected Donation</Card.Link>
                <Card.Footer>
                  7,Joshua Avenue
                </Card.Footer>
              </Card.Body>
            </Card>
            <Card style={{ width: '18rem' }}>
              <Card.Body>
                <Card.Title>Yash Patel</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">Clothes</Card.Subtitle>
                <Card.Text>
                  I want to donate my old clothes and shoes
                </Card.Text>
                <Card.Link href="#" className="btn btn-collect btn-outline-success" >Collected Donation</Card.Link>
                <Card.Footer>
                  7,Joshua Avenue
                </Card.Footer>
              </Card.Body>
            </Card>
            <Card style={{ width: '18rem' }}>
              <Card.Body>
                <Card.Title>Yash Patel</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">Clothes</Card.Subtitle>
                <Card.Text>
                  I want to donate my old clothes and shoes
                </Card.Text>
                <Card.Link href="#" className="btn btn-collect btn-outline-success" >Collected Donation</Card.Link>
                <Card.Footer>
                  7,Joshua Avenue
                </Card.Footer>
              </Card.Body>
            </Card>
            <Card style={{ width: '18rem' }}>
              <Card.Body>
                <Card.Title>Yash Patel</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">Clothes</Card.Subtitle>
                <Card.Text>
                  I want to donate my old clothes and shoes
                </Card.Text>
                <Card.Link href="#" className="btn btn-collect btn-outline-success" >Collected Donation</Card.Link>
                <Card.Footer>
                  7,Joshua Avenue
                </Card.Footer>
              </Card.Body>
            </Card>
            <Card style={{ width: '18rem' }}>
              <Card.Body>
                <Card.Title>Yash Patel</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">Clothes</Card.Subtitle>
                <Card.Text>
                  I want to donate my old clothes and shoes
                </Card.Text>
                <Card.Link href="#" className="btn btn-collect btn-outline-success" >Collected Donation</Card.Link>
                <Card.Footer>
                  7,Joshua Avenue
                </Card.Footer>
              </Card.Body>
            </Card>
            <Card style={{ width: '18rem' }}>
              <Card.Body>
                <Card.Title>Yash Patel</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">Clothes</Card.Subtitle>
                <Card.Text>
                  I want to donate my old clothes and shoes
                </Card.Text>
                <Card.Link href="#" className="btn btn-collect btn-outline-success" >Collected Donation</Card.Link>
                <Card.Footer>
                  7,Joshua Avenue
                </Card.Footer>
              </Card.Body>
            </Card>
          </Row>
        </Container>
      </div>
    )
  }
}
