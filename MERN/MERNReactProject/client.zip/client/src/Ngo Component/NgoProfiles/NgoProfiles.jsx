import React, { Component } from 'react';
import './NgoProfiles.css';
import { Container, Row, Col } from 'react-bootstrap';

export default class NgoProfiles extends Component {
    render() {
        return (
            <div>
                <Container fluid className="thankyou ngo-profile">
                    <Row>
                        <Col>
                            <h1>YMP's Ngo</h1>
                        </Col>
                    </Row>
                </Container>
            </div>
        )
    }
}
