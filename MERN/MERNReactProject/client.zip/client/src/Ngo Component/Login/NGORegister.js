import React, { Component } from 'react'
import { Row, Col } from 'react-bootstrap'
import './Login.css';
import axios from 'axios'
export default class NGORegister extends Component {
    handleSubmit = event =>{
        event.preventDefault();
        const config= {
            headers: {
                'Content-Type': 'application/json'
            }
        }
        const data={
            name:event.target.name.value,
            email:event.target.email.value,
            password:event.target.pass.value,
            phone:event.target.phone.value,
            link:event.target.link.value,
            address:event.target.address.value,
            detail:event.target.details.value,
        }
        axios.post('https://ngonodeapi.herokuapp.com//api/ngos/',data,{config})
        .then(res => {
            localStorage.setItem('ngoToken',res.data.token);
            this.props.history.push('/ngo/donations');
        }
        ).catch(err =>{
            alert(err);
        })
    }
    render() {
        return (
            <div fluid="xl" className="register-out-container">
                <div className="container register-container">

                    <Row noGutters={true} className=''>
                        <Col md={4}>
                            <img className="login-logo" src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fmdindiaonline.com%2Fsail%2FImages%2Fhelping_hand.png&f=1&nofb=1" alt="logo" />
                        </Col>
                        <Col md={3}>
                            <h3>NGO Register User</h3>
                        </Col>
                    </Row>
                    <form onSubmit={this.handleSubmit}>
                        <Row noGutters={true} className="text-left d-flex justify-content-center">
                            <Col md={6}>
                                <label>Name</label><br />
                                <input type="text" name="name" placeholder="Enter name here" className="form-control" />
                            </Col>
                        </Row>
                        <Row noGutters={true} className="text-left d-flex justify-content-center">
                            <Col md={6} className="text-left">
                                <label>Email</label>
                                <input type="email" name="email" className="form-control" placeholder="Enter Your email here" />
                            </Col>
                        </Row>
                        <Row noGutters={true} className="text-left d-flex justify-content-center">
                            <Col md={6} className="text-left">
                                <label>Password</label>
                                <input type="password" name="pass" className="form-control" placeholder="Enter Your Password here" />
                            </Col>
                        </Row>
                        <Row noGutters={true} className="text-left d-flex justify-content-center">
                            <Col md={6} className="text-left">
                                <label>Phone</label>
                                <input type="phone" name="phone" className="form-control" placeholder="Enter Your Phone here" />
                            </Col>
                        </Row>
                        <Row noGutters={true} className="text-left d-flex justify-content-center">
                            <Col md={6}>
                                <label>Ngo Link</label><br />
                                <input type="text" name="link" placeholder="Enter link of youtube video explaining about NGo " className="form-control" />
                            </Col>
                        </Row>
                        <Row noGutters={true} className="text-left d-flex justify-content-center">
                            <Col md={6} className="text-left">
                                <label>Address</label>
                                <textarea placeholder="Enter address here" name="address" rows="5" className="form-control" style={{ resize: "none" }}>
                                </textarea>
                            </Col>
                        </Row>
                        <Row noGutters={true} className="text-left d-flex justify-content-center">
                            <Col md={6} className="text-left">
                                <label>Ngo Details</label>
                                <textarea placeholder="Enter Ngo Details for Users" name="details" rows="5" className="form-control" style={{ resize: "none" }}>
                                </textarea>
                            </Col>
                        </Row>
                        <Row noGutters={true} className='d-flex justify-content-center'>
                            <Col md={4} className="text-left">
                                <input type="submit" value="Signup" className="btn btn-outline-primary btn-register" />
                            </Col>
                            <Col md={4} className="text-left login-label">
                                <label>Already have Account? </label>
                                <a href="/"> Login</a>
                            </Col>
                        </Row>
                    </form>

                </div>
            </div>
        )
    }
}
