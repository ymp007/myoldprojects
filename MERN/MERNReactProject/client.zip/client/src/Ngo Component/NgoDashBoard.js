import React, { Component } from 'react'
import './UserDashBoard.css'
import NavigationBar from './NavigationBar/NavigationBar'
import { Container } from 'react-bootstrap'
import Footer from './Footer/Footer'
import { Route, BrowserRouter, Switch } from 'react-router-dom'
import DonationList from './DonationList/DonationsList';
import NgoProfiles from './NgoProfiles/NgoProfiles'
export default class NgoDashBoard extends Component {
    render() {
        return (
            <div className="main-con">
                <NavigationBar />
                <Container>
                    <BrowserRouter>
                        <Switch>
                            <Route exact path="/ngo/donations" component={DonationList} />
                            <Route exact path="/ngo/profile" component={NgoProfiles} />
                            <Route exact path="/ngo/conformation" component={NgoDashBoard} />
                        </Switch>
                    </BrowserRouter>
                </Container>
                <Footer />
            </div>
        )
    }
}
