## Contribution in let's Help Ngo webapp React Part.

# Yash Patel
1. Initial Project setup
2. app.js design
3. react route setup
4. Components - Login,NgoProfiles, Navigation Bar
5. Hosting




# Heroku Deployment
https://mern-stack-node-api.herokuapp.com/

#git Repo
https://github.com/2020-Winter-ITE-5430-A/AvengersReactProject

