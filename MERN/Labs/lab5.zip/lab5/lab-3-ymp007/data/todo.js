let tasks = [
    {
        id:1,
        title: 'Task1',
        description: 'Task1 Description',
        status : false
    },
    {
        id: 2,
        title: 'Task2',
        description: 'Task2 Description',
        status : false

    },
    {
        id:3,
        title: 'Task3',
        description: 'Task3 Description',
        status : false
    },

];

module.exports = tasks;