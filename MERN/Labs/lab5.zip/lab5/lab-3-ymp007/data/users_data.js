let users = [
    {
        id:1,
        email:"patel@ymp.com",
        password:"123456789",
        name:"Yash"
    },
    {
        id:2,
        email:"akshu@ymp.com",
        password:"0987654321",
        name:"Akshu"
    },
];
module.exports = users;