const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const TaskSchema = new mongoose.Schema({
    userid: {
        type: Schema.Types.ObjectId,
        ref: 'users'
      },
    title: {
        type: String
    },
    description: {
        type: String
    },
    status:{
        type:Boolean
    }
});

const Task = mongoose.model('task',TaskSchema);

module.exports = Task;