const express = require('express');
let User = require('../../models/User');
const { check, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('config');

const router = express.Router();

//get all users list
router.post('/', async (req,res) => {
    try{
        const userData = await User.find({email:req.body.email});
        if(!userData){
            res.status(500).send("can't find");
        }else{
        //   console.log(userData[0].password); 
         if(bcrypt.compareSync(req.body.password,userData[0].password)){
             
            const payload = {
                user : {
                    id : userData[0]._id,
                    name: userData[0].name
                }
            };
            jwt.sign(payload, config.get('jwtsecret'),{expiresIn:360000},(err,token)=>{
                if(err) throw err
                res.json({token});
            });
         }  
        } 
    }catch(err){
        res.status(500).send("Sorry username/password is wrong");
    }
});

module.exports = router;