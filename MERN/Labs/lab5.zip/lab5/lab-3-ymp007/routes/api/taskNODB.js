const express = require('express');
let Task = require('../../models/Task');
const { check, validationResult } = require('express-validator');
const auth = require('../../middleware/auth');

const router = express.Router();

//route Get api/tasks
//desc Get all tasks
//access public
router.get('/',auth, async (req,res) => {
    try{
        const TaskDB = await Task.find();
        res.send(TaskDB);
    }catch(err){
        res.status(500).send('server error');
    }
});
router.get('/:id',async (req,res) => {
    const task =await Task.findById(req.params.id);
    if(!task){
        res.status(404).send('not found');
    }else{
        res.json(task);
    }
    
});

router.delete('/:id',auth, async (req,res) => {
    try {
     await Task.findByIdAndDelete({_id: req.params.id},async (err,data)=>{
        if(!err){
            const TaskDB = await Task.find();
        res.send(TaskDB);
        }
     });

    } catch (error) {
        res.status(404).send('not found');
    }
    
});

//route post api/tasks
//desc insert task
//access public

router.post('/',auth,[
    check('title').not().isEmpty(),
    check('description').isLength({min:12})
],async(req,res)=>{

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.array() });
    }
    const newTask = new Task({
        userid : req.user.id,
        title : req.body.title,
        description: req.body.description,
        status: false
    });
    await newTask.save();
    const TaskDB = await Task.find();
        res.send(TaskDB);
});

router.post('/:id',auth,[
    check('title').not().isEmpty(),
    check('description').isLength({min:12})
], async (req,res)=>{
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.array() });
    }
    try{
    const taskU = await Task.findOne({_id:req.params.id});
    console.log(req.user);
    if(taskU.userid === req.user.id){
        res.send(taskU);
    if(!taskU){
        return res.status(422).send("can't find task");
    }
    taskU.title = req.body.title;
    taskU.description = req.body.description;
    taskU.status = req.body.status;
    taskU.save();
    res.send(taskU);
    //await Task.updateOne({'title':req.body.title},{$set: {'title':req.body.title,'description':req.body.description,'status':false}});
    const TaskDB = await Task.find();
        res.send(TaskDB);
    }else{
        res.status(400).send("error you can't access ")
    }
    }catch(err){
        res.status(400).send(err.message);
    }
});

module.exports = router;
