package com.example.calculator;

public class Calculator {
    String numberString;
    String detailString;
    double number=0;
    int num1,num2=0;
    String operation="";
    boolean flag = false;
    Calculator(){
        numberString="0";
        detailString="";
    }

    public String getNumberString() {
        return numberString;
    }

    public void setNumberString(String numberString) {
        this.numberString = numberString;
    }

    public String getDetailString() {
        return detailString;
    }

    public void setDetailString(String detailString) {
        this.detailString = detailString;
    }

    void numberClicked(int num){
        detailString=detailString+num;
        if(num>0){
            number=number*10+num;
            numberString=String.valueOf(number);
        }
    }

    void clearClicked(){
        number=0;
        numberString="0";
        detailString="";
        num1=0;
        num2=0;
    }

    public int getNum1() {
        return num1;
    }

    public void setNum1(int num1) {
        this.num1 = num1;
    }

    public int getNum2() {
        return num2;
    }

    public void setNum2(int num2) {
        this.num2 = num2;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    void operationClicked(String op){

        //detailString=detailString+op;
        if(operation==""){
            num2 = Integer.parseInt(numberString);
        operation = op;
        flag = true;
        }else{
            num1 = Integer.parseInt(numberString);
            num2=(num2+num1);
            numberString=String.valueOf(num2);
            operation=op;
            flag = false;
        }
        number=0;
        numberString=String.valueOf(0);
        detailString = String.valueOf(num2)+op;
    }
}
