<?php
require 'lib/information_mangement.php';
?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title>AddStudent</title>
	 <link rel="stylesheet" type="text/css" href="css/main.css"/>
   </head>
   <body>
   <h1>Student Data Form</h1>
	<table id="inputs">
     <form method="post">
	 <tr>
       <td><label>ID:</label></td><td><input type="text" name="id"  value="<?php if (isset($id)) {
         echo $id;
       }  ?>"/></td>
	   </tr>
       <tr>
       <td><label>Name: </label></td><td><input type="text" name="name" value="<?php if (isset($name)) {
         echo $name;
       }  ?>"/></td>
	   </tr>
       <tr>
       <td><label>Email: </label></td><td><input type="email" name="email" value="<?php if (isset($email)) {
         echo $email;
       }  ?>"/></td>
	   </tr>
       <tr>
       <td><label>Program: </label></td><td><input type="text" name="program" value="<?php if (isset($program)) {
         echo $program;
       }  ?>"/></td>
	   </tr></table>
	   <div id="button_group">
       <input type="submit" class="buttons" name="add" value="Add"/>
       <input type="submit" class="buttons" name="search" value="Search"/>
       <input type="submit" class="buttons" name="update" value="Update"/>
       <input type="submit" class="buttons" name="delete" value="Delete"/><br>
        <input type="submit" class="buttons" id="list" name="list" value="List of Student"/>
		</div>
     </form>
	 <br>
     <br>

     <?php
     if(isset($output)){
     echo $output;
   }?>
   </body>
 </html>
