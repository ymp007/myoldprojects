<?php
$name="";
$id="";
$email="";
$program="";
$idarray=array();
require 'Database.php';
$query = "SELECT id FROM students";
$pdostm = $dbconn->prepare($query);
$pdostm->setFetchMode(PDO::FETCH_OBJ);
$pdostm->execute();

  foreach ($pdostm as $student) {
  array_push($idarray,$student->id);
}
if(isset($_POST['add'])){
if (isset($_POST['name'])&&isset($_POST['email'])&&isset($_POST['program'])) {
  $name=$_POST['name'];
  $email=$_POST['email'];
  $program=$_POST['program'];
  if($name==""||$email==""||$program==""){
    echo "<p>Please Enter Valid Data</p>";
  }else{
  $query = "insert into students (name,email,program) values ('".$name."','".$email."','".$program."')";
  $pdostm = $dbconn->prepare($query);
  $count=$pdostm->execute();
  echo "<p>Student is Added to the List</p>";
  $name="";
  $id="";
  $email="";
  $program="";
}
}
}else if(isset($_POST['list'])){
  $query = "SELECT * FROM students";
  $pdostm = $dbconn->prepare($query);
  $pdostm->setFetchMode(PDO::FETCH_OBJ);
  $pdostm->execute();
  $output = "<table border='1' id = 'display_data'style='border-collapse:collapse'>";

   foreach ($pdostm as $student){
        $output = $output. "<tr>";
		$output = $output."<td>".$student->id."</td>";
       $output = $output."<td>".$student->name."</td>";
       $output = $output."<td>".$student->email."</td>";
       $output = $output."<td>".$student->program."</td>";
       $output = $output."</tr>";
     }

   $output = $output."</table>";
}elseif (isset($_POST['search'])) {
  if(isset($_POST['id'])){

  $id = $_POST['id'];
  if($id!=""&&in_array($id,$idarray)){
  $query = "SELECT * FROM students WHERE id = $id";
  $pdostm = $dbconn->prepare($query);
  $pdostm->setFetchMode(PDO::FETCH_OBJ);
  $pdostm->execute();
  foreach ($pdostm as $student){
       $name = $student->name;
       $id = $student->id;
       $email = $student->email;
       $program = $student->program;
    }
	echo "<p>Student Found</p>";
  }else{
	  echo "<p class='error'>Please Enter Valid Value</p>";
  }
  }
}elseif (isset($_POST['delete'])) {
  if(isset($_POST['id'])){

  $id = $_POST['id'];
  if($id!=""&&in_array($id,$idarray)){
  $query = "DELETE FROM students WHERE id = $id";
  $pdostm = $dbconn->prepare($query);
  $pdostm->setFetchMode(PDO::FETCH_OBJ);
  $pdostm->execute();
  echo "<p>Student Data Deleted</p>";
}else {
	
	echo "<p class='error'>Please Enter Valid ID</p>";

}
  }
}elseif(isset($_POST['update'])){
	if(isset($_POST['id'])){

  $id = $_POST['id'];
  if($id!=""&&in_array($id,$idarray)){
	$name=$_POST['name'];
  $email=$_POST['email'];
  $program=$_POST['program'];
  if($name==""||$email==""||$program==""){
    echo "<p class='error'>Please Enter Valid Data</p>";
  }else{
  $query = "update students set name='".$name."',email='".$email."',program='".$program."' Where id = ".$id;
  $pdostm = $dbconn->prepare($query);
  $count=$pdostm->execute();
  echo "<p>Student Data Updated</p>";
  $name="";
  $id="";
  $email="";
  $program="";
		}		
		}else{
			echo "<p class='error'>Please Enter Valid ID to Update Data</p>";
		}
	}
}
 ?>