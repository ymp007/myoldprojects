<?php

  $user = "root";
  $pass = "";
  $dsn = "mysql:host=localhost;dbname=mydb";
  $dbconn = new PDO($dsn,$user,$pass);
  $dbconn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
 ?>
