<header>
	<a href="Main.php"><img src="img/humber.png" width="300px" height="70px" id="logo"></a>
	<h1>Concern Form</h1>
</header>