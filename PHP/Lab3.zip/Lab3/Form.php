<?php
if (isset($_POST['name'])) {
$name = $_POST['name'];
$namePattern = "/[a-zA-Z]{2,10}/";
if($name===""){
	$nameError="Please Enter Name";
}elseif (!preg_match($namePattern, $name)) {
	$nameError="Please Enter Valid Name";
}}
if(isset($_POST['email'])){
$email = $_POST['email'];
if($email===""){
	$emailError="Please Enter Email";
}elseif (!filter_input(INPUT_POST, 'email',FILTER_VALIDATE_EMAIL)) {
	$emailError="Please Enter Valid Email";
}}
if(isset($_POST['check_list'])){
	if(!empty($_POST['check_list'])){
		$Assignment = false;
		$Lab=false;
		$Class=false;
		foreach ($_POST['check_list'] as $selected) {
			switch ($selected) {
				case 'assignment':
					$Assignment=true;
					break;
				case 'lab':
					$Lab=true;
					break;
				case 'class':
					$Class=true;
					break;
				default:
					break;
			}
		}
		if(!$Assignment&&!$Lab&&!$Class){
			$errorcheckbox ="error";
		}
	}
}
if(isset($_POST['subject'])){
	$selectedoption = $_POST['subject'];
}
if(isset($_POST['question'])){
$question = $_POST['question'];
if($question===""){
	$questionError="Please Enter Question";
}}
?>
<form action="" name="concernform" method="post">
	<table>
	<tr>
	<td><label>Enter Your Name: </label></td><td><input type="text" name="name" value="<?php if(isset($name))
	 echo $name?>" /><label id="errorn"><?php if(isset($nameError)){
		echo $nameError;
	} ?></label></td></tr>
	<tr>
	<td><label>Enter Your Email: </label></td><td><input type="email" name="email" value="<?php 
	if(isset($email))
		echo $email
	?>" /><label id="errore"><?php if(isset($emailError)){
		echo $emailError;
	} ?></label></td></tr>
	<tr>
	<td><label>Do you want immediate Reply?</label></td><td><label>Yes</label><input type="radio" name="response" value="yes" <?php
		if(isset($_POST['response'])){
			if($_POST['response']==="yes"){
				echo "checked";
			}else{
				$response = "no";
			}
		}
	?>/><label>NO</label><input type="radio" name="response" value="no" <?php
		if (isset($response)) {
			echo "checked";
		}
	?> /></label></td></tr>
	<tr>
	<td><label>Where did you faced this difficulty : </label></td><td><input type="checkbox" name="check_list[]" value="assignment" <?php
	if(isset($Assignment)){
		if($Assignment){
			echo "checked";
		}}
	?>/><label>Assignment</label><br/><input type="checkbox" name="check_list[]" value="lab" <?php
	if(isset($Lab)){
		if($Lab){
			echo "checked";
		}}
	?>/><label>Lab</label><br/>
	<input type="checkbox" name="check_list[]" value="class" <?php
	if(isset($Class)){
		if($Class){
			echo "checked";
		}}
	?>/><label>Class</label><label><?php
		if (isset($errorcheckbox)) {
			echo $errorcheckbox;
		}
	?><br/>
	</td></tr>
	<tr>
	<td><label>Select Subject : </label></td><td><select name="subject">
		<option value="php" <?php
			if(isset($selectedoption)){
				if ($selectedoption==="php") {
						echo "selected";
					}	
			}
		?>>PHP</option>
		<option value="j2ee"<?php
			if(isset($selectedoption)){
				if ($selectedoption==="j2ee") {
						echo "selected";
					}	
			}
		?>>J2EE</option>
		<option value="android"<?php
			if(isset($selectedoption)){
				if ($selectedoption==="android") {
						echo "selected";
					}	
			}
		?>>Android</option>
		<option value="ios"<?php
			if(isset($selectedoption)){
				if ($selectedoption==="ios") {
						echo "selected";
					}	
			}
		?>>Ios</option>
		<option value="bigdata"<?php
			if(isset($selectedoption)){
				if ($selectedoption==="bigdata") {
						echo "selected";
					}	
			}
		?>>Big Data</option>
	</select></td></tr>
	<tr>
	<td><label>Enter your Question here : 
	 </label></td><td><textarea  name="question" rows="5" cols="40"  placeholder="Write Your Question here" id="question" style="resize: none;"><?php 
	 if (isset($question)) {
	 	echo $question;
	 }
	 ?></textarea><label id="errorq"><?php if(isset($questionError)){
		echo $questionError;
	} ?></label></td></tr>
	<tr>
	<td><input type="submit" value="Submit" id="submit" /></td></tr>
	</table>
</form>