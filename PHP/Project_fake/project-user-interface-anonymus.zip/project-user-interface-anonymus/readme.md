## HR Management System

The project is intended to create a HR based management system which is used to various aspects related to an HR and employee role.

## Database Design

<img src="./images/DatabaseDesign.JPG" width="800" height="600"> 

## Technologies Used

<img src="./images/HTML.png" width="100" height="100"> 
<img src="./images/CSS.png" width="100" height="100"> 
<img src="./images/javascript.png" width="100" height="100"> 
<img src="./images/php.png" width="100" height="100"> 
<img src="./images/xampp.png" width="100" height="100"> 

## App Use Case

Job search and job application is one of the process which is very common throughout the world. HR acts as the middleman between actual job and the employee.
Its very much needed for an organization to have a decent management system for the HR process
The HR management system includes the following

1. Job Postings and Job listings
2. Hiring Employees
3. Keeping Track of the employees details
4. Providing an orgaization with the best resource available .

## Work/Pages Done By

1. Yash Patel :- login.php
2. Sachin Jhaveri :- index.php
3. Arun Ghera :- empLogin.php
4. Jainam Suthar
