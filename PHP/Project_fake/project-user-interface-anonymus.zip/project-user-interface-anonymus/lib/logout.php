<?php
session_start();
header("Location: ../hr/login.php");

session_destroy();



?>