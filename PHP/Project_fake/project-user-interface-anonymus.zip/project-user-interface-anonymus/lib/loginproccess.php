<?php
session_start();
require_once "Database.php";
$flag = false;
if(isset($_POST['username']) && isset($_POST['password'])){
    $db = Database::getConnection();
    $sql = "SELECT * FROM user";
        $pdostm = $db->prepare($sql);
        $pdostm->setFetchMode(PDO::FETCH_OBJ);
        $pdostm->execute();
        $users = $pdostm->fetchAll();
        foreach($users as $user){
            if($user->username == $_POST['username'] && $user->Password == $_POST['password']){
                $_SESSION['username']=$user->username;
                header("Location: ../hr/index.php");
                $flag=true;
            }
        }
        if(!$flag){
        $_SESSION['error'] = "Sorry Username or Password is wrong";
        header("Location: ../hr/login.php");
        }
}

?>