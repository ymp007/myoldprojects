<?php
class Database
{
    private static  $user = 'root';
    private static $pass = '';
    private static $dsn = "mysql:host=localhost;dbname=pro";
    private static $db;

    private function __construct() {
        #code..
    }

    public static function getConnection(){
        if(!isset(self::$db)) {
            try {
                self::$db = new PDO(self::$dsn, self::$user, self::$pass);
                self::$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch (PDOException $e) {
               exit();
            }
        }
        return self::$db;
    }
}
?>