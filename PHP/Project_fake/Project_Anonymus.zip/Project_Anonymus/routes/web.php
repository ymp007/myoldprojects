<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//*************************************************************************
//HR
//*************************************************************************

//login
Route::get('/', 'LoginController@hr');

//dashboard
Route::get('/dashboard', 'DashboardController@dashboard');

//employee list
Route::get('/department', 'DepartmentController@departmentlist');
Route::get('/employeelist', 'DepartmentController@employeelist');
Route::get('/profile', 'DepartmentController@profile');
Route::get('/editemployee', 'DepartmentController@editprofile');

//employee Work
Route::get('/worklist', 'DepartmentWorkController@departmentlist');
Route::get('/departmentworklist', 'DepartmentWorkController@employeelist');
Route::get('/addtask', 'DepartmentWorkController@addtask');

//meeting
Route::get('/meeting', 'MeetingController@meeting');
Route::get('/addmeeting', 'MeetingController@addmeeting');


//JobPosting
Route::get('/jobposting', 'JobPosting@joblist');
Route::get('/jobapplications', 'JobPosting@jobapplicationlist');

//Vacation
Route::get('/vacationrequest', 'VacationController@vacationlist');
Route::get('/servicerequest', 'VacationController@servicerequestlist');

//*************************************************************************
//Employee
//*************************************************************************

//emplogin
Route::get('/emp/', 'LoginController@employee');

//empdashboard
Route::get('/emp/dashboard', 'DashboardController@empdashboard');

//empjobposting
Route::get('/emp/jobposting', 'JobPostingEmployee@jobpostinglist');

//MyPay
Route::get('/emp/salary', 'SalaryController@mypay');

//service Request
Route::get('/emp/servicerequest', 'VacationController@serviceform');

//vaction form
Route::get('/emp/vacationrequest', 'VacationController@vacationform');

//clockin data
Route::get('/emp/clock', 'ClockController@clock');