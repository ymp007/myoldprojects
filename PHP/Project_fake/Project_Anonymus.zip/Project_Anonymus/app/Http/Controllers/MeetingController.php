<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MeetingController extends Controller
{
    public function meeting(){
    	return view('hr.meeting.meeting');
    }
    public function addmeeting(){
    	return view('hr.meeting.addmeeting',['apllicationlist'=>$apllication]);
    }
}
