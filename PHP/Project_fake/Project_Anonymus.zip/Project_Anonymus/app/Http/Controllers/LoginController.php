<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function hr(){
    	return view('hr.login');
    }
    public function employee(){
    	return view('employee.empLogin');
    }
}
