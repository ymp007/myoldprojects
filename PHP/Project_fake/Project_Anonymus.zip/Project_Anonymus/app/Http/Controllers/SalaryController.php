<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SalaryController extends Controller
{
    public function mypay(){
    	return view('employee.mypay.salary');
    }
    }
