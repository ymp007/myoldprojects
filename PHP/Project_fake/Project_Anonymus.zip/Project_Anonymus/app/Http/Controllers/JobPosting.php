<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JobPosting extends Controller
{
	public function joblist(){
		return view('hr.jobposting.jobpostinglist');	
	}
    public function jobapplicationlist(){
    	return view('hr.jobposting.jobapplications');
    }
    }
}
