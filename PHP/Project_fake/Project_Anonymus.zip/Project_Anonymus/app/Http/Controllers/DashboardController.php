<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function dashboard()
    {
    	/*$tasks = Task::all();*/
    	return view('hr.dashboard');	
    }
    public function empdashboard()
    {
    	/*$tasks = Task::all();*/
    	return view('employee.dashboard');	
    }
}
