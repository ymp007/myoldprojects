<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DepartmentWorkController extends Controller
{
    public function departmentlist(){
    	return view('hr.employeework.departmentwork');
    }

    public function employeelist(){
    	return view('hr.employeework.employeeworklist');
    }

    public function addtask(){
    	return view('hr.employeework.addtask');
    }
}
