<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DepartmentController extends Controller
{
    public function departmentlist(){
    	return view('hr.employeelist.department');
    }

    public function employeelist(){
    	return view('hr.employeelist.employeelist');
    }

    public function profile(){
    	return view('hr.employeelist.profile');
    }

    public function editprofile(){
    	return view('hr.employeelist.addeditemployee');
    }
}
