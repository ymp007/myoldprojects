<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JobPostingEmployee extends Controller
{
    public function jobpostinglist(){
    	return view('employee.jobposting.jobpostinglist');
    }
    public function jobapplicationlist(){
    	return view('employee.jobposting.jobapplications');
    }
}
