<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VacationController extends Controller
{
	public function vacationlist(){
    return view('hr.vacation.vacationlist');
	}

	public function vacationform(){
		return view('employee.vacation.vacationform');		
	}

	public function servicerequestlist(){
		return view('hr.vacation.servicerequest');	
	}
	public function serviceform(){
		return view('employee.vacation.servicerequestform');
	}
}
