
<?php
require_once 'PageClass.php';
require_once 'PageChildClass.php';

$page= new PageChildClass();
$page->assign_css();
$page->apply_css();
$page->create_page_background("img/back.jpg");
$page->assign_header_links();
$page->create_header("img/logo.png");
$page->create_pageHeading("Welcome To Braca Forca");
$page->assign_data();
$page->assign_footer_links();
$page->create_footer();
?>