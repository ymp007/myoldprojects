<?php
class PageChildClass extends PageClass{
	public function assign_header_links()
	{
		$links=["Contact US"=>"contactus.php","News"=>"News.php","Merchandise"=>"Merchandise.php","SqadMembers"=>"SqadMembers.php","Home"=>"Main.php"];
		parent::setLinks($links);
		$logourl=["https://www.fcbarcelona.com/en/"=>"img/logo.png","https://messi.com"=>"img/Messi.png"];
		parent::setLogoUrl($logourl);
	}
	public function assign_footer_links(){
		$linksfooter=["SocialAccounts"=>"Hello.php","Contact US"=>"contactus.php","Careers"=>"Careers.php","Merchandise"=>"Merchandise.php","SqadMembers"=>"SqadMembers.php","Home"=>"Main.php"];
		parent::setLinks($linksfooter);
		$socialLinks=["img/social_logos/fb.png"=>"https://www.facebook.com","img/social_logos/tw.png"=>"https://www.twitter.com","img/social_logos/insta.png"=>"https://www.instagram.com"];
		parent::setSocialLinks($socialLinks);
	}
	public function assign_css(){
		parent::setcsslink("css/mainCss.css");
	}

	public function assign_data(){
		$data="<p id='Content'>Want to see the most emblematic corners of the stadium? To walk on the pitch? Go in the FC Barcelona dressing room? You’ll get all this and more with the Barça Stadium Tour & Museum. Buy your ticket now and feel like one more member of the squad!<br><br><br><a href='barcamech.com' id='button'>Click Here</a></p>
		 ";
		parent::create_Content($data);
	}
}
?>