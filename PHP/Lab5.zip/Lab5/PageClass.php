
<?php

	class PageClass{
	    	private $links=[];
			private $logourl;
			private $socialLinks;
			private $csslink;


			public function __construct(){
			}
			public function create_page_background($backgroundurl){
				echo "<body style='background-image: url(".$backgroundurl.")'>";
			}
			//setters	
			public function setLinks($linksvalue){
			$this->links = $linksvalue;
			}
			public function setSocialLinks($linksvalue){
			$this->socialLinks = $linksvalue;
			}
			public function setLogoUrl($logoLinks){
			$this->logourl = $logoLinks;
			}
			public function setcsslink($css_Links){
			$this->csslink = $css_Links;
			}

			//Create Navigation
	        function display_navigation(){
	 		$put="";
			foreach ($this->links as $key => $value) {
			$put=$put."<li><a href=".$value.">".$key."</a></li>";
			}
			return $put;
			}

			//Create Header
			function create_header($logourl){
				echo "<header>";
						echo "<a href='Main.php'><img src=".$logourl." width='70px' height='70px' id='logo'></a>
						<nav id='headernav'>
								<ul>". $this->display_navigation()."</ul>
							</nav>
						</header>";
			}

			//Create Footer
			function create_footer(){
					 echo "<footer>";
					 echo "<nav class='footernav'>";
					 echo "<ul>";
					 echo $this->display_navigation();
					 echo "</ul>";
					 echo "</nav>";
					 echo "<div id='links'style='margin-left:45vw'>";
					 foreach ($this->socialLinks as $key => $value) {
					 	 echo "<a href=".$value."><img src='".$key."'/></a>";
					 }
					 echo "</div>";
					 echo "</footer>";
			}
			//Apply Css
			function apply_css(){
				echo "<head>";
				echo "<link rel='stylesheet' type='text/css' href=".$this->csslink.">";
				echo "</head>";
			}
			public function create_pageHeading($heading){
				echo "<h1 style='text-align:center;color:white'>".$heading."</h1>";
			}
			public function create_Content($data){
				echo "<main>";
				echo "<div id='imageLinks'>";
				foreach($this->logourl as $key=> $value){
					echo "<a href=".$key."><img src='".$value."'/></a>";
				}
				echo "</div>";
				echo $data;
				echo "</main>"; 
			}
	    }

	?>
