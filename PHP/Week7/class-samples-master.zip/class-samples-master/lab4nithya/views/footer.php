<footer id='footer'>
    <?php
    $footer_menu = [
        "Privacy" => "privacy.php",
        "Contact" => "contact.php"
    ];
    echo displayNavigation($footer_menu);
    ?>
    <div>
        <p>©2019 Humber College</p>
    </div>
</footer>
</body>
</html>

