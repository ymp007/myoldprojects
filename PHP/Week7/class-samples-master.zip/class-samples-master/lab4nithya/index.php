<?php
require_once 'library/functions.php';
require_once 'library/validations.php';
include_once "views/header.php";
include_once "views/content.php";
include_once "views/footer.php";

