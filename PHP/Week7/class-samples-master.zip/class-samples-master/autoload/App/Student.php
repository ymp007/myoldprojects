<?php

namespace App;


class Student
{
    public function test(){
        echo "hello student";
    }
}