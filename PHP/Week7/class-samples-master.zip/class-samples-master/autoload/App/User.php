<?php
namespace App;

class User
{
 public function test(){
     echo "hello user";
 }
}