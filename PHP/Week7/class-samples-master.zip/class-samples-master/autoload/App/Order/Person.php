<?php
namespace App\Order;
class Person {
    public function test(){
        echo  'Hi Person';
    }
}