<?php
namespace Appnew;
class Page {
    public function display(){
        echo "page";
    }
}