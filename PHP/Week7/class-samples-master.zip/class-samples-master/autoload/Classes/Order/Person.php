<?php
class Person {
    public function test()
    {
        echo 'hi person';
    }
}