<?php


class Usera
{
 public function test(){
     echo "hello usera";
 }
}