<?php

class Studenta
{
    public function test(){
        echo "hellos studenta";
    }
}