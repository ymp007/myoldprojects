<?php
class Test {
    public function test(){
        echo "test";
    }
}