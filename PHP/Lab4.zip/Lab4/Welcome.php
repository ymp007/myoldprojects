<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
</head>
<body>
<h1>Thank you.<br>
Professor will give you Response as soon as possible</h1>
</body>
</html>