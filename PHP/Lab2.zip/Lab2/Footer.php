<footer>
	<div id="links">
	<a href="http://www.facebook.com/humbercollege/"><img src="img/fb.png" width="70px" height="50px"></a>
	<a href="http://www.twitter.com/humbercollege"><img src="img/tw.png" width="50px" height="50px"></a>
	<a href="http://www.instagram.com/humbercollege" style="margin-left: 1em"><img src="img/insta.png" width="50px" height="50px"></a>
	</div>
</footer>