<!DOCTYPE html>
<html>
<head>
	<title>Ask Question</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
<?php
include 'Header.php';
include "Form.php";
include 'Footer.php';
 ?>
</body>
</html>