<form action="Welcome.php" name="concernform" onsubmit="return validateform()" method="post">
	<table>
	<tr>
	<td><label>Enter Your Name: </label></td><td><input type="text" name="name"/><label id="errorn"></label></td></tr>
	<tr>
	<td><label>Enter Your Email: </label></td><td><input type="email" name="email"/><label id="errore"></label></td></tr>
	<tr>
	<td><label>Do you want immdiate Reply?</label></td><td><label>Yes</label><input type="radio" name="student" value="yes" /><label>NO</label><input type="radio" name="student" value="no" checked /></td></tr>
	<tr>
	<td><label>Where did you faced this difficulty : </label></td><td><input type="checkbox" name="spendings" value="rent" /><label>Assignment</label><br/><input type="checkbox" name="time" value="5" /><label>Lab</label><br/>
	<input type="checkbox" name="spendings" value="food" /><label>Class</label><br/>
	</td></tr>
	<tr>
	<td><label>Select Subject : </label></td><td><select name="subject">
		<option value="php">PHP</option>
		<option value="j2ee">J2EE</option>
		<option value="android">Android</option>
		<option value="ios">Ios</option>
		<option value="bigdata">Big Data</option>
	</select></td></tr>
	<tr>
	<td><label>Enter your Question here : 
	 </label></td><td><textarea  name="question" rows="5" cols="40" placeholder="Write Your Question here" id="question" style="resize: none;"></textarea><label id="errorq"></label></td></tr>
	<tr>
	<td><input type="submit" value="Submit" id="submit" /></td></tr>
	</table>
</form>
<script type="text/javascript">
	function validateform () {
		name=document.concernform.name.value;
		email=document.concernform.email.value;
		document.getElementById('errorn').innerHTML="";
		document.getElementById('errore').innerHTML="";
		document.getElementById('errorq').innerHTML="";
		namer= new RegExp(/^[A-Za-z]+$/);
		emailr = new RegExp(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/);

		if(name===""||name===null){
			
			document.getElementById('errorn').innerHTML="Please Enter Name";
			return false;
		
		}else if(!namer.test(name)){
			document.getElementById('errorn').innerHTML="Please Enter Valid Name";
			return false;
		}else if (email===""||email===null) {
			document.getElementById('errore').innerHTML="Please Enter Email";
			return false;
		}else if (!emailr.test(email)) {
			document.getElementById('errore').innerHTML="Please Enter Valid Email";
			return false;
		}else if (document.concernform.question.value==="") {
			document.getElementById('errorq').innerHTML="Please Ask Proper Question";
			return false;
		}

	}
</script>