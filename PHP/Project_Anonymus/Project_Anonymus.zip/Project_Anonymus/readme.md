## HR Management System

The project is intended to create a HR based management system which is used to various aspects related to an HR and employee role.

## Database Design

<img src="./images/DatabaseDesign.JPG" width="800" height="600">

## Technologies Used

<p float="left">
<img src="./images/HTML.png" width="100" height="100"> 
<img src="./images/CSS.png" width="100" height="100"> 
<img src="./images/javascript.png" width="100" height="100"> 
<img src="./images/php.png" width="100" height="100"> 
<img src="./images/xampp.png" width="100" height="100">
</p>

## App Use Case

Job search and job application is one of the process which is very common throughout the world. HR acts as the middleman between actual job and the employee.
Its very much needed for an organization to have a decent management system for the HR process
The HR management system includes the following

1. Job Postings and Job listings
2. Hiring Employees
3. Keeping Track of the employees details
4. Providing an orgaization with the best resource available .

## How to start using

a. Locally.

1.Install latest PHP version (PHP 7) from [here](https://windows.php.net/download/)<br>
2.Install latest XAMPP version with PHP 7.2 or above [here](https://www.apachefriends.org/blog/new_xampp_20171220.html)

-   Clone the repository.
-   Got to master and do the below steps

```sh
 composer update
 php artisan serve
```

## 3. Required files.

-   Create a `.git` file .
-   Have the basic settings according to your database in the format below for `LOCAL`<br>
    `DB_CONNECTION= type of connection eg.(mysql/postgres)`<br>
    `DB_HOST= localhost/127.0.0.1`  
    `DB_PORT= database port here`<br>
    `DB_DATABASE= db name`<br>
    `DB_USERNAME= db username`<br>
    `DB_PASSWORD= db password`<br>

b. Deployment Enviornmemt

## ENJOY !!

## Work/Pages Done By

1. Yash Patel :- login.php
2. Sachin Jhaveri :- index.php
3. Yash Patel :- login,editprofile,empprofile,clock,employeeList,employeeWork,meetings
4. Sachin Jhaveri :- dashboard,jobApplication,serviceRequest,task
5. Arun Ghera :- empLogin.php
6. Jainam Suthar :-jobposting.php
