<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//*************************************************************************
//HR
//*************************************************************************

//login
Route::get('/', 'LoginController@hr');
Route::post('/hrlogin','LoginController@hrlogin');

//logout
Route::get('/logout','LoginController@hrlogout');

//dashboard
Route::get('/dashboard', 'DashboardController@dashboard');

//employee list
Route::get('/department', 'DepartmentController@departmentlist');
Route::get('/employeelist/{dep}', 'DepartmentController@employeelist');
Route::get('/employeelist/profile/{id}', 'DepartmentController@profile');
Route::get('/editemployee/{id}', 'DepartmentController@editprofile');
Route::get('/editemployee/delete/{id}', 'DepartmentController@destroy');
Route::get('/editemployee', 'DepartmentController@addprofile');
Route::post('/editemployee/update', 'DepartmentController@updateprofile');
Route::post('/editemployee/add', 'DepartmentController@addEmployee');

//employee Work
Route::get('/worklist', 'DepartmentWorkController@departmentlist');
Route::get('/departmentworklist/{dep}', 'DepartmentWorkController@employeelist');
Route::get('/addtask', 'DepartmentWorkController@addtask');

//meeting
Route::get('/meeting', 'MeetingController@meeting');
Route::get('/addmeeting', 'MeetingController@addmeeting');
Route::get('/meeting/delete/{mid}', 'MeetingController@deletemeeting');
Route::get('/updatedatameeting/{mid}', 'MeetingController@updatemeeting');
Route::post('/addmeetingrequest', 'MeetingController@addmeetingrequest');
Route::post('/updatemeetingrequest', 'MeetingController@updatemeetingrequest');



//JobPosting
Route::get('/jobposting', 'JobPostingController@index');
Route::resource('/jobposting', 'JobController');
// Route::get('/jobposting', 'JobPosting@joblist');
Route::get('/jobapplications', 'JobPosting@jobapplicationlist');

//Vacation
Route::resource('/vacationrequest', 'VacationController');
//Route::get('/vacationrequest', 'VacationController@vacationlist');
Route::get('/servicerequest', 'VacationController@servicerequestlist');

//*************************************************************************
//Employee
//*************************************************************************

//emplogin
Route::get('/emp/', 'LoginController@employee');
Route::post('/emp/login','LoginController@login');

//empdashboard
Route::get('/emp/dashboard', 'DashboardController@empdashboard');

//empjobposting
Route::get('/emp/jobposting', 'JobPostingEmployee@jobpostinglist');

//MyPay
Route::get('/emp/salary', 'SalaryController@mypay');

//MyPay
Route::post('/emp/salary', 'SalaryController@mypaycalculated');

//service Request
Route::get('/emp/servicerequest', 'VacationController@serviceform');

//submit task
Route::get('/emp/submittask','SubmittaskController@submittask');

//vaction form
Route::get('/emp/vacationrequest', 'VacationController@vacationform');

//vaction submit form
Route::post('/emp/vacationrequest', 'VacationController@vacationsubmitform');

//feedback form
Route::get('/emp/feedback', 'FeedbackController@feedbackform');

//feedback submit form
Route::post('/emp/feedback', 'FeedbackController@feedbacksubmitform');


//clockin data
Route::get('/emp/clock', 'ClockController@clock');

//employee profile
Route::get('/emp/profile','ClockController@clock');
Route::get('/emp/profile/{Employees}','ProfileController@showProfile');

Route::get('/emp/editprofile/{id}','ProfileController@editProfile');
Route::post('/emp/editprofile/update','ProfileController@updateProfile');