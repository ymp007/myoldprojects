<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobListModel extends Model
{
    protected $table = 'job_postings';
    protected $primaryKey = 'id';
    public $timestamps = false;
}
