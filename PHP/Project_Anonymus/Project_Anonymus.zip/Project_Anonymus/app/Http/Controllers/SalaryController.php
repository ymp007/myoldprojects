<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\AttendanceModel;

class SalaryController extends Controller
{
    public function mypaycalculated(){
        $attendance = AttendanceModel::all();
    	return view('employee.mypay.salary', ['attendance' => $attendance]);
    }

    public function mypay(){
        return view('employee.mypay.salary');

    }
    

    }
