<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Department;
use App\Meetings;

class DashboardController extends Controller
{
    public function dashboard()
    {
    	$meetings = Meetings::select("*")->get();
                $department = Department::select('*')->get();
                return view('hr.dashboard',["meetings"=>$meetings,"department"=>$department]);	
    }
    public function empdashboard()
    {
    	/*$tasks = Task::all();*/
    	return view('employee.dashboard');	
    }
}
