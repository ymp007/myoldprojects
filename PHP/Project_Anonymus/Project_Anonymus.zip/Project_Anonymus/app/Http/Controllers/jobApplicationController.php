<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
class jobApplicationController extends Controller
{
    public function applyjob(){
    	return view('employee.jobApplication.jobApplication');
    }
}