<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\VacationFormModel;

class VacationController extends Controller
{
	public function vacationlist(){
    return view('hr.vacation.vacationlist');
	}

	public function vacationform(){
		
		
		return view('employee.vacation.vacationform');		
	}

	public function servicerequestlist(){
		return view('hr.vacation.servicerequest');	
	}
	public function serviceform(){
		return view('employee.vacation.servicerequestform');
	}
	public function vacationsubmitform(Request $request){
		$this->validate($request, [
			'Vacation_Start_Date' => 'required',
			'Vacation_End_Date' => 'required',
			'Vacation_Reason' => 'required',
			'Employee_ID' => 'required',
			'id' => 'required'
		]);
		VacationFormModel::create($request->all());

       return redirect('emp/dashboard');

	}
}
