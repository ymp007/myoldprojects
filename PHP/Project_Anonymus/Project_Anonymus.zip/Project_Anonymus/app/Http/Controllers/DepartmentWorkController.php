<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employees;
use App\Login;
use App\Department;

class DepartmentWorkController extends Controller
{
    public function departmentlist(){
    	return view('hr.employeework.departmentwork');
    }

    public function employeelist($dep){
    	 $department = Department::select('name')->where('id',$dep)->get();
            $employee = Employees::select('*')->where('Employee_Designation',$dep)->get();
    	return view('hr.employeework.employeeworklist',["deaprtment"=>$department,"employee"=>$employee]);
    }

    public function addtask(){
    	return view('hr.employeework.addtask');
    }
}
