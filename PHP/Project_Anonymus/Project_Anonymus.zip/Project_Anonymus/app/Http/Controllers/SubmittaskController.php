<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;

class SubmittaskController extends Controller{
    public function submittask()
    {
        return view('employee.submittask.submitTask');
    }
}
?>