<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employees;
use App\Login;
use App\Department;

class ProfileController extends Controller
{
     public function showProfile($id){
    	
     	$username = Login::select('username')->where('Employee_ID',$id)->get();
        $employee = Employees::select('*')->where('id',$id)->get();
        $department = Department::select('name')->where('id',$employee[0]->Employee_Designation)->get();
    	return view('employee.profile.empprofile',["employee"=>$employee,"username"=>$username,"department"=>$department]);
    }

    public function editProfile($id){
    	$username = Login::select('*')->where('Employee_ID',$id)->get();
        $employee = Employees::select('*')->where('id',$id)->get();
        $department = Department::select('*')->get();
    	return view('employee.profile.editprofile',["employee"=>$employee,"username"=>$username,"department"=>$department]);
    }

    public function updateProfile(Request $request){
    	$employee = Employees::find($request->Employee_ID);
        $employee->Employee_Name = $request->name;
        $employee->Employee_Email = $request->email;
        $employee->Employee_Phone = $request->phone;
        $employee->Employee_Address = $request->address;
        $employee->Employee_Skills = $request->skills;
        $employee->save();
        $user = Login::find($request->Employee_ID);
        $user->username = $request->username;
        $user->Password = $request->password;
        $user->save();
        $emp=$employee->Employee_ID;
        return redirect()->route('/emp/profile/'.$emp);
    }
}
