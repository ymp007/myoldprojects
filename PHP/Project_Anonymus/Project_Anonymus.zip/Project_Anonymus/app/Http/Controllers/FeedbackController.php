<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\FeedbackFormModel;

class FeedbackController extends Controller
{
    public function feedbackform(){
		
		
		return view('employee.feedback.feedbackform');		
    }
    public function feedbacksubmitform(Request $request){
		$this->validate($request, [
			'Feedback_Description' => 'required',
			'Employee_ID' => 'required',
			'Feedback_Subject' => 'required'
			
		]);
		FeedbackFormModel::create($request->all());

       return redirect('emp/dashboard');
		
			
	}
}
