<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Department;
use App\Meetings;

class MeetingController extends Controller
{
    public function meeting(){
    	$meetings = Meetings::select("*")->get();
    	$department = Department::select('*')->get();

    	return view('hr.meeting.meeting',["meetings"=>$meetings,"department"=>$department]);
    }
    public function addmeeting(){
    	$department = Department::select('*')->get();
    	return view('hr.meeting.addmeeting',["department"=>$department]);
    }
    public function addmeetingrequest(Request $request){
    	$meeting = new Meetings();
    	$this->validate($request,[
    		'department' => 'required',
    		'head' => 'required',
    		'duration' => 'required',
    		'description' => 'required',
    		'date' => 'required',
    		'time' => 'required'

    	]);
    	$meeting->dept_id = $request->department;
    	$meeting->Meeting_Head = $request->head;
    	$meeting->Meeting_Duration = $request->duration;
    	$meeting->Meeting_Description = $request->description;
    	$meeting->Date = $request->date;
    	$meeting->Time = $request->time;
    	$meeting->save();
    	
    	$meetings = Meetings::select("*")->get();
    	$department = Department::select('*')->get();

    	return view('hr.meeting.meeting',["meetings"=>$meetings,"department"=>$department]);
    }

    public function updatemeeting($mid){
    	$meetings = Meetings::select("*")->where("Meeting_ID",$mid)->get();
    	$department = Department::select('*')->get();
    	return view('hr.meeting.addmeeting',["department"=>$department,"meetings"=>$meetings]);	
    }

    public function deletemeeting($mid){
    	Meetings::find($mid)->delete();
    	$meetings = Meetings::select("*")->get();
    	$department = Department::select('*')->get();

    	return view('hr.meeting.meeting',["meetings"=>$meetings,"department"=>$department]);
    }

    public function updatemeetingrequest(Request $request){
    	
    	$this->validate($request,[
    		'department' => 'required',
    		'head' => 'required',
    		'duration' => 'required',
    		'description' => 'required',
    		'date' => 'required',
    		'time' => 'required'

    	]);
    	$meeting = Meetings::find($request->meeting_id);

    	$meeting->dept_id = $request->department;
    	$meeting->Meeting_Head = $request->head;
    	$meeting->Meeting_Duration = $request->duration;
    	$meeting->Meeting_Description = $request->description;
    	$meeting->Date = $request->date;
    	$meeting->Time = $request->time;
    	$meeting->save();
    	
    	$meetings = Meetings::select("*")->get();
    	$department = Department::select('*')->get();

    	return view('hr.meeting.meeting',["meetings"=>$meetings,"department"=>$department]);	
    }
}
