<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Login;
use App\EmpLogin;
use App\Department;
use App\Meetings;

class LoginController extends Controller
{
     public function hr(){
    	return view('hr.login');
    }
    public function employee(){
    	return view('employee.empLogin');
    }
    public function login(Request $request){
    	$this->validate($request,[
    		'username' => 'required|min:3',
    		'password' => 'required'
    	]);
       $employee = Login::select('*')->where('username',$request->username)->get();
        if($employee!=null){
        	foreach ($employee as $emp) {
        	if (Hash::check($request->password, $emp->Password)){
        		session(['username'=>$request->username]);
                session(['emp_id'=>$emp->Employee_ID]);

    			return view('employee.dashboard');		
        	}		
        	}
        	return view('employee.empLogin');
        	
    	}else{
            return view('employee.empLogin');
        }
    }

    public function hrlogin(Request $request){
    		$this->validate($request,[
    		'hrusername' => 'required|min:3',
    		'password' => 'required'
    	]);
		$hr = EmpLogin::select('*')->where('hrusername',$request->hrusername)->get();
        if($hr!=null){
        	foreach ($hr as $emp) {
        	if(Hash::check($request->password,$emp->password)){
        		session(['username'=>$request->hrusername]);
                session(['employee'=>$emp->id]);
                $meetings = Meetings::select("*")->get();
                $department = Department::select('*')->get();
    			return view('hr.dashboard',["meetings"=>$meetings,"department"=>$department]);		
        	}		
        	}
        	return view('hr.login');
        	
    	}else{
            return view('hr.login');
        }
    }

    public function hrlogout(Request $request){
        $request->session()->flush();
        return view('hr.login');
    }
}
