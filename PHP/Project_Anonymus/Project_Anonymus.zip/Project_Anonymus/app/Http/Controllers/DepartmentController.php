<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use App\Employees;
use App\Login;
use App\Department;


class DepartmentController extends Controller
{
    public function departmentlist(){
    	$department = Department::select('*')->get();
        return view('hr.employeelist.department',["department"=>$department]);
    }

    public function employeelist($dep){
         $department = Department::select('name')->where('id',$dep)->get();
            $employee = Employees::select('*')->where('Employee_Designation',$dep)->get();
            foreach ($department as $dep1) {
                return view('hr.employeelist.employeelist',["employees"=>$employee,"department"=>$dep1->name]);             
                 }     
         
    	
    }

    public function profile($id){
        $username = Login::select('username')->where('Employee_ID',$id)->get();
        $employee = Employees::select('*')->where('id',$id)->get();
        $department = Department::select('name')->where('id',$employee[0]->Employee_Designation)->get();
    	return view('hr.employeelist.profile',["employee"=>$employee,"username"=>$username,"department"=>$department]);
    }

    public function editprofile($id){
        $username = Login::select('*')->where('Employee_ID',$id)->get();
        $employee = Employees::select('*')->where('id',$id)->get();
        $department = Department::select('*')->get();
    	return view('hr.employeelist.addeditemployee',["employee"=>$employee,"username"=>$username,"department"=>$department]);
    }
    public function addprofile(){
        $department = Department::select('*')->get();
        return view('hr.employeelist.addeditemployee',["department"=>$department]);
    }
    public function updateprofile(Request $request){
        $employee = Employees::find($request->Employee_ID);
        $employee->Employee_Name = $request->name;
        $employee->Employee_Email = $request->email;
        $employee->Employee_Phone = $request->phone;
        $employee->Employee_Address = $request->address;
        $employee->Employee_Skills = $request->skills;
        $employee->Employee_Designation = $request->department;
        $employee->Employee_Salary = $request->salary;

        $employee->save();
        $user = Login::find($request->Employee_ID);
        $user->username = $request->username;
        $user->Password = $request->password;
        $user->save();
        $department = Department::select('*')->get();
        return view('hr.employeelist.department',["department"=>$department]);
    }

    public function addEmployee(Request $request){
        /*$this->validate($request,[
            'file' => 'file|required'

        ]);*/
        return $request->file('myphoto');

        $employee = new Employees();
        $employee->id = $request->Employee_ID;
        $employee->Employee_Name = $request->name;
        $employee->Employee_Email = $request->email;
        $employee->Employee_Phone = $request->phone;
        $employee->Employee_Address = $request->address;
        $employee->Employee_Skills = $request->skills;
        $employee->Employee_Designation = $request->designation;
        $employee->Employee_Salary = $request->salary;
        if($request->has('myphoto')){
        $file = $request->file('myphoto')->storeAs('images',$request->Employee_ID."jpg");
        dd($file);
        $employee->save();
        $user = new Login();
        $user->Employee_ID = $request->Employee_ID;
        $user->Password = $request->password;
        $user->username = $request->username;
        $user->save();
    }
        return view('hr.employeelist.department');
    }

    public function destroy($empid){
            Login::find($empid)->delete();
            Employees::find($empid)->delete();
            return view('hr.employeelist.department');
    }
}
