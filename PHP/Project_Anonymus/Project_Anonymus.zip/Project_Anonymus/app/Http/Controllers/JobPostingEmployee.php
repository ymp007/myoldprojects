<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\JobListModel;

class JobPostingEmployee extends Controller
{
    public function jobpostinglist(){
        $jobs = JobListModel::all();
        return view('employee.jobposting.jobpostinglist', ['jobs' => $jobs]);
    	//return view('employee.jobposting.jobpostinglist');
    }
    public function jobapplicationlist(){
    	return view('employee.jobposting.jobapplications');
    }
}
