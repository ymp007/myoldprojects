<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VacationFormModel extends Model
{
    protected $table = 'vacation';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable =['Vacation_Start_Date','Vacation_End_Date', 'Vacation_Reason','Employee_ID','id'];
}


