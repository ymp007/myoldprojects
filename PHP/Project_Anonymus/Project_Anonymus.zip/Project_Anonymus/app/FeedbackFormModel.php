<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeedbackFormModel extends Model
{
    protected $table = 'feedback';
    public $timestamps = false;
    protected $fillable =['Feedback_Description','Employee_ID', 'Feedback_Subject'];
}
