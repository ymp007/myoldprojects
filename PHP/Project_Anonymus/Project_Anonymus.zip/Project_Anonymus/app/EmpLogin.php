<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmpLogin extends Model
{
    protected $table = 'hrlogindetails';
	protected $primaryKey = 'Employee_ID';
	public $timestamps = false;
}
