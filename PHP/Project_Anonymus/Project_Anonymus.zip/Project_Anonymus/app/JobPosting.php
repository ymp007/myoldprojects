<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobPosting extends Model
{
    protected $table = 'job_postings';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable =['Job_ID','Job_Description','Application_Deadline','open_seats'];
    public function job(){
        return $this->belongsTo('App\Job','Job_ID','id');
    }
}

